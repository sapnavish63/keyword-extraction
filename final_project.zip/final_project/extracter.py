import os,re,traceback,nltk
import datefinder
from datetime import datetime,date


def convertToText(filepath,filename) :
    file_name, ext = os.path.splitext(filename)
    string = ""
    try :
        if ext.lower() == '.docx' : 
            import docx2txt
            string = docx2txt.process(filepath+filename)
        elif ext.lower() == '.pdf' :
            """from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
            from pdfminer.converter import TextConverter
            from pdfminer.layout import LAParams
            from pdfminer.pdfpage import PDFPage
            from io import StringIO

            rsrcmgr = PDFResourceManager()
            retstr = StringIO()
            codec = 'utf-8'
            laparams = LAParams()
            device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
            fp = open(filepath+filename, 'rb')
            interpreter = PDFPageInterpreter(rsrcmgr, device)
            password = ""
            maxpages = 0
            caching = True
            pagenos=set()
            for page in PDFPage.get_pages(fp, pagenos, maxpages=maxpages, password=password,caching=caching, check_extractable=True):
                interpreter.process_page(page)
            fp.close()
            device.close()
            string = retstr.getvalue()
            retstr.close()"""
            string = ""
            import PyPDF2
            pdfFileObj = open(filepath+filename, 'rb')
            pdfReader = PyPDF2.PdfFileReader(pdfFileObj)
            pages = pdfReader.numPages
            for x in range(0,pages):
                print(x)
                pageObj = pdfReader.getPage(x)
                string = string + pageObj.extractText()
            print(string)
    except Exception as e:
        print(e)
    return string

def processData(inputString):
    lines = []
    lines = [el.strip() for el in inputString.splitlines() if len(el) > 0]  # Splitting on the basis of newlines 
    lines = [nltk.word_tokenize(el) for el in lines]    # Tokenize the individual lines
    lines = [nltk.pos_tag(el) for el in lines]
    return lines

def extractEmail(inputString) :

    email_id = ""
    try :
        inputString = inputString.replace("\n" ,"")
        print(inputString)
        email_ids = regex = re.findall('[a-zA-Z0-9+._-]+@[a-zA-Z0-9._-]+\.[com]+',inputString)
        print(email_ids)

        if len(email_ids) > 0:
            email_id = email_ids[0]
        else :
            email_ids = re.findall('@\S+', inputString)
            #print(email_ids)
            if len(email_ids) > 0 :
                email_id = email_ids[0]
                email_id = email_id[:email_id.index('.com')+4]
                while True:
                    index = inputString.index(email_id)
                    index = index -1
                    val = inputString[index]
                    #print(val)
                    if val.isalpha() or val.isnumeric() or val =='\n' or val == '.' or val == '-':
                        email_id = val + email_id
                    else :
                        break
                email_id = email_id.replace("\n","")
    except Exception as e :
        print(e)
    return email_id

def extractName(inputString):
    first_name = ""
    last_name = ""
    try:
        indianNames = open("allNames.txt", "r").read().lower()
        indianNames = set(indianNames.split())
        otherNameHits = []
        nameHits = []
        name = None
        lines = []
        lines = processData(inputString)
        grammar = r'NAME: {<NN.*><NN.*><NN.*>*}'
        chunkParser = nltk.RegexpParser(grammar)
        all_chunked_tokens = []
        for tagged_tokens in lines:
            if len(tagged_tokens) == 0: continue # Prevent it from printing warnings
            chunked_tokens = chunkParser.parse(tagged_tokens)
            all_chunked_tokens.append(chunked_tokens)
            for subtree in chunked_tokens.subtrees():
                if subtree.label() == 'NAME':
                    for ind, leaf in enumerate(subtree.leaves()):
                        if leaf[0].lower() in indianNames and 'NN' in leaf[1]:
                            hit = " ".join([el[0] for el in subtree.leaves()[ind:ind+3]])
                            if re.compile(r'[\d,:]').search(hit): continue
                            nameHits.append(hit)
        if len(nameHits) > 0:
            nameHits = [re.sub(r'[^a-zA-Z \-]', '', el).strip() for el in nameHits] 
            name = " ".join([el[0].upper()+el[1:].lower() for el in nameHits[0].split() if len(el)>0])
            otherNameHits = nameHits[1:]

    except Exception as e:
        print (traceback.format_exc())
        print(e)         

    if name :
        name = name.split(" ")
        first_name = name[0]
        last_name = name[len(name) -1]
    return first_name, last_name  

# def extractName(inputString) :
#     my_lower_text = inputString.lower()
#     first_name = ""
#     last_name = ""
#     if 'name' in my_lower_text :
#         index = my_lower_text.index("name")
#         sub =inputString[index+4:index+50]
#         for val in sub :
#             if (val.isalpha() or val.isnumeric()) and val !='\n' :
#                 final = sub[sub.index(val):]
#                 print("value ="+ val)
#                 break
#         print(final)
#         if "\n" in final :
#             newl = final.index('\n')
#             final = final[:newl]
#         print(final)
#         nameArr = final.split(" ")
#         first_name = nameArr[0]
#         last_name = final[final.index(" ")+1:]
#         print(nameArr)
#     return {'first_name' : first_name,'last_name' : last_name}

def extractMobile(inputString) :
    number = ""
    try:
        inputString = inputString.replace(" ","")
        inputString = inputString.replace("\n","")
        pattern = re.compile(r'([+(]?\d+[)\-]?[ \t\r\f\v]*[(]?\d{2,}[()\-]?[ \t\r\f\v]*\d{2,}[()\-]?[ \t\r\f\v]*\d*[ \t\r\f\v]*\d*[ \t\r\f\v]*)')
        match = pattern.findall(inputString)
        match = [re.sub(r'[,.]', '', el) for el in match if len(re.sub(r'[()\-.,\s+]', '', el))>6]
        match = [re.sub(r'\D$', '', el).strip() for el in match]
        match = [el for el in match if len(re.sub(r'\D','',el)) <= 15]
        try:
            for el in list(match):
                if len(el.split('-')) > 3: continue # Year format YYYY-MM-DD
                for x in el.split("-"):
                    try:
                        if x.strip()[-4:].isdigit():
                            if int(x.strip()[-4:]) in range(1900, 2100):
                                match.remove(el)
                    except:
                        pass
        except:
            pass
        number = match
    except Exception as e:
        print(e)
    if len(number) > 0 :
        number = number[0]
    return number

def extractPincode(inputString) :
    pincode = ""
    try :
        regex= re.compile(r"(\b\d{6}\b)")
        matches = re.findall(regex, inputString)
        inputString = inputString.replace("\n","")
        if len(matches) > 0 :
            pincode = matches[0]
        else : 
            alt_regex = re.compile(r"(\b['\n']\d{6}/*\b)")
            print("Inside")
            print(inputString)
            alt_matches = re.findall(alt_regex, inputString)
            if len(alt_matches) > 0 :
                pincode = alt_matches[0]
            else :
                pincode = ""
                substring = ""
                valIndex = 0
                for val in inputString :
                    valIndex = valIndex + 1
                    if val.isnumeric() or val =='\n' or val == '-':
                        substring = substring + val
                        if val.isnumeric() :
                            pincode = pincode + val
                            print(pincode)
                    else :
                        pincode = ""
                        substring = ""
                    if len(pincode) == 6:
                        print("strt:"+substring+":end")
                        index1 = inputString.index(substring)
                        startChar = inputString[index1-1:index1]
                        #startChar = startChar if startChar != '\n' else inputString[index1-2:index1-1]
                        print("startChar : " + startChar)
                        print("value :" + val+":")
                        nextChar = inputString[valIndex+1:valIndex+2]
                        #nextChar = nextChar if nextChar != '\n' else inputString[valIndex+2:valIndex+3]
                        print("nextchar : " + str(nextChar))
                        if not nextChar.isnumeric() and not startChar.isnumeric():
                            break
                        else :
                            pincode = ""
                            substring = ""
    except Exception as e:
        print(e)
    return pincode


def extractExperience(inputString):
    lines = processData(inputString)
    experience=[]
    try:
        for sentence in lines:#find the index of the sentence where the degree is find and then analyse that sentence
                sen=" ".join([words[0].lower() for words in sentence]) #string of words in sentence
                if re.search('experience',sen):
                    sen_tokenised= nltk.word_tokenize(sen)
                    tagged = nltk.pos_tag(sen_tokenised)
                    entities = nltk.chunk.ne_chunk(tagged)
                    for subtree in entities.subtrees():
                        for leaf in subtree.leaves():
                            if leaf[1]=='CD':
                                experience=leaf[0]
    except Exception as e:
        print (traceback.format_exc())
        print (e) 
    # if experience:
    #     infoDict['experience'] = experience
    # else:
    #     infoDict['experience']=0
    # if debug:
    #     print ("\n", pprint(infoDict), "\n")
    #     code.interact(local=locals())
    if not experience :
        experience = 0
    return experience


def getQualification(inputString,infoDict,D1,D2):
    #key=list(qualification.keys())
    try:           
        qualification={'institute':'','year':''}
        nameofinstitutes=open('nameofinstitutes.txt','r').read().lower()#open file which contains keywords like institutes,university usually  fond in institute names
        nameofinstitues=set(nameofinstitutes.split())
        instiregex=r'INSTI: {<DT.>?<NNP.*>+<IN.*>?<NNP.*>?}'
        chunkParser = nltk.RegexpParser(instiregex)
    
        index=[]
        line=[]#saves all the lines where it finds the word of that education
        lines = processData(inputString)
        for ind, sentence in enumerate(lines):#find the index of the sentence where the degree is find and then analyse that sentence
            sen=" ".join([words[0].lower() for words in sentence]) #string of words
            if re.search(D1,sen) or re.search(D2,sen):
                index.append(ind)  #list of all indexes where word Ca lies
        if index:#only finds for Ca rank and CA year if it finds the word Ca in the document
            
            for indextocheck in index:#checks all nearby lines where it founds the degree word.ex-'CA'
                for i in [indextocheck,indextocheck+1]: #checks the line with the keyword and just the next line to it
                    try:
                        try:
                            wordstr=" ".join(words[0] for words in lines[i])#string of that particular line
                            # print(wordstr)
                        except:
                            wordstr=""
                        #if re.search(r'\D\d{1,3}\D',wordstr.lower()) and qualification['rank']=='':
                                #qualification['rank']=re.findall(r'\D\d{1,3}\D',wordstr.lower())
                                #line.append(wordstr)
                        if re.search(r'\b[21][09][8901][0-9]',wordstr.lower()) and qualification['year']=='':
                                qualification['year']=re.findall(r'\b[21][09][8901][0-9]',wordstr.lower())
                                line.append(wordstr)
                        chunked_line = chunkParser.parse(lines[i])#regex chunk for searching univ name
                        for subtree in chunked_line.subtrees():
                                if subtree.label()=='INSTI':
                                    for ind,leaves in enumerate(subtree):
                                        if leaves[0].lower() in nameofinstitutes and leaves[1]=='NNP' and qualification['institute']=='':
                                            qualification['institute']=' '.join([words[0]for words in subtree.leaves()])
                                            line.append(wordstr)
                            
                    except Exception as e:
                        print (traceback.format_exc())
        if D1=='c\.?a':
            infoDict['%sinstitute'%D1] ="I.C.A.I"
        else:
            if qualification['institute']:
                infoDict['%sinstitute'%D1] = str(qualification['institute'])
            else:
                infoDict['%sinstitute'%D1] = "NULL"
        if qualification['year']:
            infoDict['%syear'%D1] = int(qualification['year'][0])
        else:
            infoDict['%syear'%D1] =0
        infoDict['%sline'%D1]=list(set(line))
    except Exception as e:
        print (traceback.format_exc())
        print (e) 


def extractQualification(inputString,infoDict={},debug=False):
    degre=[]
    infoDict['degree'] = []
    #Q={'CAinformation':'','ICWAinformation':'','B.Cominformation':'','M.Cominformation':'','MBAinformation':''}
    #degree=[]
    #degree1=open('degree.txt','r').read().lower()#string to read from the txt file which contains all the degrees
    #degree=set(el for el in degree1.split('\n'))#saves all the degrees seperated by new lines,degree name contains both abbreviation and full names check file
    #qualification1={'CAline':'','CAcollege':'','CArank':'','CAyear':''}
    print("here")
    try :
        getQualification(inputString,infoDict,'C\.?A','chartered accountant')
        if infoDict['%sline'%'C\.?A']:
         degre.append('ca')
        getQualification(inputString,infoDict,'icwa','icwa')
        if infoDict['%sline'%'icwa']:
         degre.append('icwa')
        getQualification(inputString,infoDict,'b\.?com','bachelor of commerce')
        if infoDict['%sline'%'b\.?com']:
         degre.append('b.com')
        getQualification(inputString,infoDict,'m\.?com','masters of commerce')
        if infoDict['%sline'%'m\.?com']:
         degre.append('m.com') 
        getQualification(inputString,infoDict,'MBA','MBA')
        if infoDict['%sline'%'MBA']:
         degre.append('mba')
        getQualification(inputString,infoDict,'ssc','secondary examination')
        if infoDict['%sline'%'ssc']:
         degre.append('ssc')
        getQualification(inputString,infoDict,'hsc','hsc')
        if infoDict['%sline'%'hsc']:
         degre.append('hsc')
        getQualification(inputString,infoDict,'bca','bachelor of computer applications')
        if infoDict['%sline'%'bca']:
         degre.append('bca')
        getQualification(inputString,infoDict,'BE','bachelor of engineering')
        if infoDict['%sline'%'BE']:
         degre.append('BE')
        if degre:
            infoDict['degree'] = degre
        else:
            infoDict['degree'] = ""
        print(infoDict['degree'])
    except Exception as e :
        print(e)
    return (", ".join(infoDict['degree'])).upper()


def extractDOB(inputString) :
    from dateutil.parser import parse
    print("\n\n\n")
    dob = ""
    try :
        inputString = inputString.replace("\n","").replace(" ","").replace("\t","").replace(","," ").lower()
        posibilities = ["dob",'d.o.b','dateofbirth', ' birthdate']
        for pos in posibilities :
            if pos in inputString :
                index = inputString.index(pos)
                inputString = inputString[index+len(pos) : ]
                numIndex = 0
                for el in inputString:
                    if el.isnumeric( ):
                        numIndex = inputString.index(el) 
                inputString = inputString[ : numIndex+40]
                match = re.findall('\d{4}', inputString)
                print(match)
                if len(match) > 0:
                    yrIndx = inputString.index(match[0])
                    inputString = inputString[:yrIndx+4]
                break
        print(inputString)
        if "august" in inputString :
            inputString = inputString.replace("august","aug")
        char_list = ['st', 'nd', 'rd', 'th']
        inputString = re.sub("|".join(char_list), "", inputString)
        is_failed = True
        matches = datefinder.find_dates(inputString)
        for match in matches:
            is_failed = False
            dob = match
            dob_year = int(dob.strftime("%Y"))
            now_year = date.today().year
            print("If")
            if dob_year == now_year :
                is_failed = True
            break

        if is_failed :
            dob_alt = parse(inputString, fuzzy_with_tokens=True)
            if dob_alt :
                dob = dob_alt[0]

    except Exception as e :
        print(e)
    if dob != "" :
        dob = dob.strftime("%d/%m/%Y")
    print("Dob :::::::: " + dob)
    return dob