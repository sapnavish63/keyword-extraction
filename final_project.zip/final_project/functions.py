def handle_upoload_file(f):
    with open('new_project/static/upload/'+f.name, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)